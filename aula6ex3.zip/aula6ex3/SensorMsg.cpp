#include <iostream>
#include "SensorMsg.h"

using namespace std;

SensorMsg::SensorMsg() {
    type_="";
    value_=0;
}

SensorMsg::SensorMsg(int source, int destination, string type, float value) {
    source_=source;
    destination_=destination;
    type_=type;
    value_=value;
    id_=++id_;
}

void SensorMsg::set_type_(string type) {
    type_=type;
}

void SensorMsg::set_value_(float value) {
    value_=value;
}

string SensorMsg::get_type_() {
    return type_;
}

float SensorMsg::get_value_() {
    return value_;
}

ostream& operator<<(ostream &os, const SensorMsg &Message){
    os << "Type: " << Message.type_
       << "Value: " << Message.value_
       << "Source: " << Message.source_
       << "Destination" << Message.destination_;
    return os;
}
