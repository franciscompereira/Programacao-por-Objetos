#ifndef AULA6EX3_ACTUATOR_H
#define AULA6EX3_ACTUATOR_H

#include <iostream>
#include "Device.h"

using namespace std;

class Actuator: public Device{
public:
    Actuator();
    //~Actuator();
    void set_is_Actuator_false();
    bool get_is_Actuator();

protected:
    bool is_Actuator=true;
};


#endif //AULA6EX3_ACTUATOR_H
