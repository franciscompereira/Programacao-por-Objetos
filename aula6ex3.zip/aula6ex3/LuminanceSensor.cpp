#include <iostream>
#include "LuminanceSensor.h"
#include "Device.h"

using namespace std;

LuminanceSensor::LuminanceSensor() {
    lux_Value=0;
}

LuminanceSensor::LuminanceSensor(string name, float luxvalue) {
    name_=name;
    lux_Value=luxvalue;
    identification_=++identification_;
}

void LuminanceSensor::set_lux_Value(float luxValue) {
    lux_Value=luxValue;
}

float LuminanceSensor::get_lux_Value() {
    return lux_Value;
}

ostream &operator<<(ostream &os,const LuminanceSensor &Sensor){
    os  << "Luminance Sensor ID:" << Sensor.identification_
        << " Name:" << Sensor.name_
        << " Value:" << Sensor.lux_Value << " lux\n";
    return os;
}

istream &operator>>(istream &is, LuminanceSensor &Sensor){
    cout << "Device name?";
    is >> Sensor.name_;
    cout << "Manufacturer name?";
    is >> Sensor.manufacturer_name;
    cout << "Luminance value?";
    is >> Sensor.lux_Value;
    return is;
}