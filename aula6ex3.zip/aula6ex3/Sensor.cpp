#include "Sensor.h"
#include <iostream>

using namespace std;

Sensor::Sensor() {
    is_Sensor=true;
}

bool Sensor::get_is_Sensor() {
    return is_Sensor;
}

void Sensor::set_is_Sensor_false() {
    is_Sensor=false;
}