#ifndef AULA6EX3_ULTRASSOUNDSENSOR_H
#define AULA6EX3_ULTRASSOUNDSENSOR_H

#include <iostream>
#include "Sensor.h"

using namespace std;

class UltrassoundSensor:public Sensor {
public:
    UltrassoundSensor();
    //~UltrassoundSensor();
    UltrassoundSensor(string name, float ultradistance);
    float get_ultrassound_Distance();
    void set_ultrassound_Distance(float ultrassounddistance);
    friend ostream& operator<<(ostream &os,const UltrassoundSensor &Sensor);

protected:
    float ultrassound_Distance; //distance between a sensor and an object
};


#endif //AULA6EX3_ULTRASSOUNDSENSOR_H
