#include <iostream>
#include "SmartLamp.h"
#include "Actuator.h"
#include "Device.h"

using namespace std;

SmartLamp::SmartLamp() {
    is_On=2;
}

SmartLamp::SmartLamp(const string &name, const string &manufacturerName, bool isOn) {
    if(is_On= false){
        is_On="OFF";
    }else is_On="ON";

    Device(name,manufacturerName);
    set_is_On(isOn);
    identification_=++identification_;
}

void SmartLamp::set_is_On_false() {
    is_On=false;
}

void SmartLamp::set_is_On_true() {
    is_On=true;
}

void SmartLamp::set_is_On(bool ison) {
    is_On=ison;
}

bool SmartLamp::get_is_on() {
    return is_On;
}

ostream& operator<<(ostream &os, const SmartLamp &Actuator){
    string Status;
    if(Actuator.is_On){
        Status = "on";
    }else{
        Status = "off";
    }
    os << "SmartLamp ID: " << Actuator.identification_
       <<"Name: " << Actuator.name_
       <<"Status: " << Status;
    return os;
};
