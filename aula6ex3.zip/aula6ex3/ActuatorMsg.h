#ifndef AULA6EX3_ACTUATORMSG_H
#define AULA6EX3_ACTUATORMSG_H

#include <iostream>
#include "Message.h"

using namespace std;

class ActuatorMsg:public Message {
public:
    ActuatorMsg();
    //~ActuatorMsg();
    ActuatorMsg(int source, int destination, string info);
    string get_info_();
    void set_info_(string &info);
    friend ostream& operator<<(ostream &os, const ActuatorMsg &Message);

protected:
    string info_;
};


#endif //AULA6EX3_ACTUATORMSG_H
