#include <iostream>
#include "UltrassoundSensor.h"
#include "Device.h"

using namespace std;

UltrassoundSensor::UltrassoundSensor() {
    ultrassound_Distance=0;
}

UltrassoundSensor::UltrassoundSensor(string name, float ultradistance) {
    name_=name;
    ultrassound_Distance=ultradistance;
    identification_=++identification_;
}

float UltrassoundSensor::get_ultrassound_Distance() {
    return ultrassound_Distance;
}

void UltrassoundSensor::set_ultrassound_Distance(float ultrassounddistance) {
    ultrassound_Distance=ultrassounddistance;
}

ostream& operator<<(ostream &os,const UltrassoundSensor &Sensor){
    os << "Ultra Sensor ID: " << Sensor.identification_
       << "Name: " << Sensor.name_
       << "Value: " << Sensor.ultrassound_Distance;
        return os;
};