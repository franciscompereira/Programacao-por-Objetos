#ifndef AULA6EX3_SENSORMSG_H
#define AULA6EX3_SENSORMSG_H

#include <iostream>
#include "Message.h"

using namespace std;

class SensorMsg: public Message {
public:
    SensorMsg();
    //~SensorMsg();
    SensorMsg(int source, int destination, string type, float value);
    string get_type_();
    float get_value_();
    void set_type_(string type);
    void set_value_(float value);
    friend ostream& operator<<(ostream &os, const SensorMsg &Message);

protected:
    string type_; // temperature or luminance message
    float value_; // temperature or luminance message value
};


#endif //AULA6EX3_SENSORMSG_H
