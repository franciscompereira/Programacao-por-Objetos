#ifndef AULA6EX3_SENSOR_H
#define AULA6EX3_SENSOR_H

#include <iostream>
#include "Device.h"

using namespace std;

class Sensor: public Device{
public:
    Sensor();
    //~Sensor();
    void set_is_Sensor_false();
    bool get_is_Sensor();
protected:
    bool is_Sensor = true;
};


#endif //AULA6EX3_SENSOR_H
