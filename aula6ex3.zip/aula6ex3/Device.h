#ifndef AULA6EX3_DEVICE_H
#define AULA6EX3_DEVICE_H

#include <iostream>

using namespace std;

class Device{
public:
    Device();
    //~Device();
    Device(string name, string manufacturername); //já possui incrementação automática de identification!!
protected:
    string name_;
    string manufacturer_name;
    static int identification_;
};

#endif //AULA6EX3_DEVICE_H
