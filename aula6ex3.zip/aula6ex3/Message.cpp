#include <iostream>
#include "Message.h"

using namespace std;

unsigned int Message::id_=99;

Message::Message() {
    source_=0;
    destination_=0;
}

Message::Message(int source, int destination) {
    source_=source;
    destination_=destination;
    id_=++id_;
}

void Message::set_destination_(int destination) {
destination_=destination;
}

void Message::set_source_(int source) {
source_=source;
}

int Message::get_destination_() {
    return destination_;
}

int Message::get_source_() {
    return source_;
}