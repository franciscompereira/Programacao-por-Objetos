#ifndef AULA6EX3_SMARTLAMP_H
#define AULA6EX3_SMARTLAMP_H

#include <iostream>
#include "Actuator.h"

using namespace std;

class SmartLamp:public Actuator {
public:
    SmartLamp();
    //~SmartLamp();
    SmartLamp(const string &name, const string &manufacturerName, bool isOn);
    void set_is_On_true();
    void set_is_On_false();
    void set_is_On(bool ison);
    bool get_is_on();
    friend ostream& operator<<(ostream &os, const SmartLamp &Actuator);

protected:
    bool is_On;
};


#endif //AULA6EX3_SMARTLAMP_H
