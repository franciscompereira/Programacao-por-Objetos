#ifndef AULA6EX3_LUMINANCESENSOR_H
#define AULA6EX3_LUMINANCESENSOR_H

#include <iostream>
#include "Sensor.h"

using namespace std;

class LuminanceSensor:public Sensor {
public:
    LuminanceSensor();
    //~LuminanceSensor();
    LuminanceSensor(string name, float luxvalue);
    float get_lux_Value();
    void set_lux_Value(float luxValue);
    friend ostream& operator<<(ostream &os,const LuminanceSensor &Sensor);
    friend istream& operator>>(istream &is, LuminanceSensor &Sensor);

protected:
    float lux_Value;
};


#endif //AULA6EX3_LUMINANCESENSOR_H
