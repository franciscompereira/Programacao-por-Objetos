#include <iostream>
#include "Device.h"
#include "Sensor.h"
#include "UltrassoundSensor.h"
#include "SmartLamp.h"
#include "LuminanceSensor.h"
#include "SensorMsg.h"
#include "ActuatorMsg.h"

using namespace std;

int main() {
    UltrassoundSensor us("sensor_presenca",5.2);
    LuminanceSensor ls("sensor_luz",33.3);
    SmartLamp sl("lampada","lightFixtures",false);
    SensorMsg sm(100,1,"luminance",5.2);
    ActuatorMsg am(1,12,"switch On");

    cout << us << ls << sl << sm << am << endl;

    cin >> ls;
    cout << ls;

    return 0;
}
