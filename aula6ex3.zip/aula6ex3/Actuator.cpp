#include <iostream>
#include "Actuator.h"

using namespace std;

Actuator::Actuator() {
    is_Actuator=true;
}

void Actuator::set_is_Actuator_false() {
    is_Actuator=false;
}

bool Actuator::get_is_Actuator() {
    return is_Actuator;
}