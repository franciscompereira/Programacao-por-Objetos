#ifndef AULA6EX3_MESSAGE_H
#define AULA6EX3_MESSAGE_H

#include <iostream>
//#include "SensorMsg.h"
//#include "ActuatorMsg.h"

using namespace std;

class Message{
public:
    Message();
    //~Message();
    Message(int source, int destination);
    int get_source_();
    int get_destination_();
    void set_source_(int source);
    void set_destination_(int destination);
protected:
    int source_;
    int destination_;
    static unsigned int id_;
};


#endif //AULA6EX3_MESSAGE_H
