#include <iostream>
#include "Device.h"

using namespace std;

int Device::identification_=9;

Device::Device() {
    name_="";
    manufacturer_name="";
}

Device::Device(string name, string manufacturername) {
    name_=name;
    manufacturer_name=manufacturername;
    identification_=++identification_;
}