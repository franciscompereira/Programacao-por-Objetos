#include <iostream>
#include "ActuatorMsg.h"
#include "Message.h"

using namespace std;

ActuatorMsg::ActuatorMsg() {
    info_="";
}

ActuatorMsg::ActuatorMsg(int source, int destination, string info) {
    source_=source;
    destination_=destination;
    set_info_(info);
    id_=++id_;
}

void ActuatorMsg::set_info_(string &info) {
    info_=info;
}

string ActuatorMsg::get_info_() {
    return info_;
}

ostream& operator<<(ostream &os, const ActuatorMsg &Message){
    os << "Info: " << Message.info_
       << "Source: " << Message.source_
       << "Destination" << Message.destination_;
    return os;
}
