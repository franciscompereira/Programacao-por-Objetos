//Francisco Pereira, nº113882
#ifndef DESAFIO1_ANIMAL_H
#define DESAFIO1_ANIMAL_H

#include <iostream>
#include "Owner.h"

using namespace std;

class Animal {
public:
    Animal();
    Animal(const string& name, const string& color, const Owner& owner){
        name_=name;
        registration_number_=5+registration_number_;
        color_=color;
        owner_=owner;
    }
    const string &get_name_();
    void set_name_(const string &name);
    const string &get_color_();
    void set_color_(const string &color);
    const Owner &get_owner_();
    void set_owner_(const Owner &owner);
    static int get_registration_number();

protected:
    string name_;
    string color_;
    static int registration_number_; //incrementar 5 a começar em 0
    Owner owner_;
};


#endif //DESAFIO1_ANIMAL_H
