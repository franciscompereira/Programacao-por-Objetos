//Francisco Pereira, nº113882

#include "Animal.h"
#include <iostream>

using namespace std;

int Animal::registration_number_=-5;

Animal::Animal() {
    name_="Unknown";
    registration_number_=-1;
    color_="Unknown";
    owner_.set_Age_(0);
    owner_.set_Name_("Unknown");
}

const string &Animal::get_name_(){
    return name_;
}

void Animal::set_name_(const string &name) {
    name_ = name;
}

const string &Animal::get_color_(){
    return color_;
}

void Animal::set_color_(const string &color) {
    color_ = color;
}

const Owner &Animal::get_owner_(){
    return owner_;
}

void Animal::set_owner_(const Owner &owner) {
    owner_ = owner;
}

int Animal::get_registration_number() {
    return registration_number_;
}

