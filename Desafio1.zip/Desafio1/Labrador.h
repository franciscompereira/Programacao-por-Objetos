//Francisco Pereira, nº113882

#ifndef DESAFIO1_LABRADOR_H
#define DESAFIO1_LABRADOR_H

#include <iostream>
#include "Dog.h"
#include "Animal.h"

//Labrador.cpp Labrador.h

class Labrador: public Dog{
public:
    Labrador() = default;
    Labrador(const string& name,const string& color, const Owner& owner, bool& istrimmed, unsigned int& vaccinestaken, bool hasaball, bool haspedigree): Dog(name, color, owner, istrimmed, vaccinestaken){
        name_=name;
        color_=color;
        owner_=owner;
        is_trimmed_=istrimmed;
        vaccines_taken_=vaccinestaken;
        has_a_ball_=hasaball;
        has_pedigree=haspedigree;
        registration_number_=5+registration_number_;
    }
protected:
    bool has_a_ball_;
    bool has_pedigree;
};


#endif //DESAFIO1_LABRADOR_H
