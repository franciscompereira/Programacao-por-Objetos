//Francisco Pereira, nº113882
#include <iostream>
#include "Owner.h"
#include "Dog.h"
#include "Bird.h"

using namespace std;

int main() {

    //a)
    Owner o1();
    Owner o2("Pedro Valente", 23,"Sardoal");

    cout << o1 << endl;
    cout << o2 << endl;


    //b)
    Dog d1;
    cin >> d1;
    cout << d1;

    //c)
    Bird b1;
    cin >> b1;
    cout << b1;

    //d)
   // Bird b2("Blu", "Blue", ("Linda Gunderson",19, "Minnesotta"), true, "Forest");


    //e)
    d1.set_name_("Speedy");
    cout << d1;

    //7.

    Dog doggy1= Dog("Tobias", "Black", Owner("Ana", 19, "Braga"), false, 2);
    cout << doggy1.get_registration_number() << endl;
    Dog doggy2=doggy1;
    cout << doggy2.get_registration_number()<< endl;

    return 0;
}
