//Francisco Pereira, nº113882

#ifndef DESAFIO1_BIRD_H
#define DESAFIO1_BIRD_H

#include <iostream>
#include "Animal.h"

using namespace std;

class Bird: public Animal{
public:
    Bird();
    Bird(const string& name, const string& color, const Owner& owner, bool producesound, const string& habitat): Animal(name, color, owner){
        name_=name;
        color_=color;
        owner_=owner;
        produce_sound_=producesound;
        habitat_=habitat;
        registration_number_=5+registration_number_;
    }
    bool get_produce_sound_() ;
    void set_produce_sound_(bool produceSound);
    const string get_habitat_() ;
    void set_habitat_(const string &habitat);
    friend ostream& operator<<(ostream &os, const Bird &bird);
    friend istream &operator>>(istream &is, Bird &bird);
private:
    bool produce_sound_;
    string habitat_;
};


#endif //DESAFIO1_BIRD_H
