//Francisco Pereira, nº113882

#include "Bird.h"
#include "Animal.h"

Bird::Bird() {
    produce_sound_=true;
    habitat_="Forest";
}

bool Bird::get_produce_sound_()  {
    return produce_sound_;
}

void Bird::set_produce_sound_(bool produceSound) {
    produce_sound_ = produceSound;
}

const string Bird::get_habitat_()  {
    return habitat_;
}

void Bird::set_habitat_(const string &habitat) {
    habitat_ = habitat;
}

ostream& operator<<(ostream &os, const Bird &bird){
    os << "Bird: " << bird.name_ << "(color: " << bird.color_ << "), number " << bird.registration_number_ << endl;
    os << bird.owner_ << endl;
    os << "Habitat: " << bird.habitat_ << endl;
    os << "Produces Sound: " << bird.produce_sound_ << endl;
    return os;
}

istream &operator>>(istream &is, Bird &bird){

    cout << "Bird input: " << endl;
    cout << "Name: ";
    is >> bird.name_;
    cout << "Color: ";
    is >> bird.color_;
    cout << "Habitat: ";
    is >> bird.habitat_;
    cout << "Produces sound (Y|N) ?";
    is >> bird.produce_sound_;
    cout << "Owner registration information. " << endl,
    is >> bird.owner_;
    cout << endl;
    return is;
}
