//Francisco Pereira, nº113882

#include <iostream>
#include "Dog.h"

using namespace std;

Dog::Dog() {
    is_trimmed_=true;
    vaccines_taken_=0;
}

bool Dog::get_is_trimmed_()  {
    return is_trimmed_;
}

void Dog::set_is_trimmed_(bool isTrimmed) {
    is_trimmed_ = isTrimmed;
}

unsigned int Dog::get_vaccines_taken()  {
    return vaccines_taken_;
}

void Dog::set_vaccines_taken(unsigned int vaccinesTaken) {
    vaccines_taken_ = vaccinesTaken;
}

ostream& operator<<(ostream &os, const Dog &dog){
    os << "Dog: " << dog.name_ << "(color: " << dog.color_ << "), number " << dog.registration_number_ << endl;
    os << dog.owner_ << endl;
    os << "Vaccines: " << dog.vaccines_taken_ << endl;
    os << "Is trimmed: " << dog.is_trimmed_ << endl;
    return os;
}

istream &operator>>(istream &is, Dog &dog){
    cout << "Dog input: " << endl;
    cout << "Name: ";
    is >> dog.name_;
    cout << "Color: ";
    is >> dog.color_;
    cout << "Vaccines taken: ";
    is >> dog.vaccines_taken_;
    cout << "Hair trimmed (Y|N)? ";
    is >> dog.is_trimmed_;
    cout << "Owner registration information. " << endl,
    is >> dog.owner_;
    return is;
}