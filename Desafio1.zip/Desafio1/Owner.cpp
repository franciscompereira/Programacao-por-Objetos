//Francisco Pereira, nº113882
#include <iostream>
#include "Owner.h"

Owner::Owner() {
    name_="Unknown";
    age_=0;
    local_="Unknown";
}

Owner::Owner(string name, unsigned int age, string local) {
    name_=name;
    age_=age;
    local_=local;
}

const string &Owner::get_Name_()  {
    return name_;
}

void Owner::set_Name_(const string &name) {
    name_ = name;
}

unsigned int Owner::get_Age_()  {
    return age_;
}

void Owner::set_Age_(unsigned int age) {
    age_= age;
}

const string &Owner::get_local_()  {
    return local_;
}

void Owner::set_local_(const string &local) {
    local_ = local;
}

ostream& operator<<(ostream &os, const Owner &owner){
    os << "Owner: " << owner.name_ << ", " << owner.age_ << " years, from " << owner.local_;
    return os;
}

istream &operator>>(istream &is, Owner &owner){
    cout << "Owner input:" << endl;
    cout << "Name: ";
    is >> owner.name_;
    cout << "Local: ";
    is >> owner.local_;
    cout << "Age: ";
    is >> owner.age_;
    return is;
}
