//Francisco Pereira, nº113882
#ifndef DESAFIO1_DOG_H
#define DESAFIO1_DOG_H

#include <iostream>
#include "Animal.h"

using namespace std;

class Dog: public Animal {
public:
    Dog();
    Dog(const string& name,const string& color, const Owner& owner, bool istrimmed, unsigned int vaccinestaken):Animal(name, color, owner){
        name_=name;
        color_=color;
        owner_=owner;
        is_trimmed_=istrimmed;
        vaccines_taken_=vaccinestaken;
        registration_number_=5+registration_number_;
    }
    bool get_is_trimmed_() ;
    void set_is_trimmed_(bool isTrimmed);
    unsigned int get_vaccines_taken() ;
    void set_vaccines_taken(unsigned int vaccinesTaken);
    friend ostream& operator<<(ostream &os, const Dog &dog);
    friend istream &operator>>(istream &is, Dog &dog);

protected:
    bool is_trimmed_;
    unsigned int vaccines_taken_;
};


#endif //DESAFIO1_DOG_H
