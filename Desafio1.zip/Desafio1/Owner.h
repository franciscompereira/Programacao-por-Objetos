//Francisco Pereira, nº113882
#ifndef DESAFIO1_OWNER_H
#define DESAFIO1_OWNER_H

#include <iostream>

using namespace std;

class Owner {
public:
    Owner();
    Owner(string name, unsigned int age, string local);
    const string &get_Name_() ;
    void set_Name_(const string &name);
    unsigned int get_Age_() ;
    void set_Age_(unsigned int age);
    const string &get_local_();
    void set_local_(const string &local);
    friend ostream& operator<<(ostream &os, const Owner &owner);
    friend istream &operator>>(istream &is, Owner &owner);
private:
    string name_;
    unsigned int age_;
    string local_;
};


#endif //DESAFIO1_OWNER_H
