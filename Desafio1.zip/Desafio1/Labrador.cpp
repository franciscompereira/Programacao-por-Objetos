//Francisco Pereira, nº113882

#include <iostream>
#include "Labrador.h"

using namespace std;

